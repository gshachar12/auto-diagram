"""
PANGEA - Grounder stage.

Implements the LLM Grounder component of the PANGEA pipeline, per PANGEA_SPEC:

    Network Traffic Description ─┐
                                  ├─> Claim Extractor  ─> claims[] + actors[] (roles only)
    (text only, no PCAP access)  ┘
                                        │
    Reduced PCAP + Fingerprint_index ──┤
                                        ▼
                                Evidence Matcher ─> resolved actors + grounded claims
                                        │
                                        ▼
                              Matching JSON (final Grounder output)

See grounder.py for the top-level Grounder class that wires these together.
"""

from .grounder import Grounder
from .claim_extractor import ClaimExtractor
from .evidence_matcher import EvidenceMatcher
from .models import (
    Actor,
    Claim,
    ExpectedIndicators,
    Grounding,
    GroundingStatus,
    MatchingResult,
)

__all__ = [
    "Grounder",
    "ClaimExtractor",
    "EvidenceMatcher",
    "Actor",
    "Claim",
    "ExpectedIndicators",
    "Grounding",
    "GroundingStatus",
    "MatchingResult",
]
