"""
Evidence Matcher (Grounder sub-component #2).

Per PANGEA_SPEC:
  Responsibility: determine, for each claim, whether the Reduced PCAP supports it -
  and resolve actor roles to actual IP endpoints.
  Input: claims + actors (from Claim Extractor), Reduced PCAP, Fingerprint_index.

  Actor Resolution (sub-responsibility):
    - Search Fingerprint_index for traffic patterns matching a role's expected
      structural signature (e.g. "attacker" -> high destination-cardinality source).
    - Single unambiguous match -> resolved automatically, confidence + basis.
    - No match -> actor marked unresolved; dependent claims flagged
      uncertain_needs_drilldown without a wasted lookup.
    - Multiple competing matches -> escalate to the LLM with only the candidates.

  Claim Grounding (per claim):
    - Depends on unresolved actor -> immediately uncertain_needs_drilldown.
    - Otherwise build a fingerprint key from structured expected_indicators, look
      it up in Fingerprint_index.
    - Single clean match -> grounded, with linked packet IDs / aggregate refs.
    - No match at all -> unsupported (false-positive candidate).
    - Match exists only as aggregate/compressed stats -> uncertain_needs_drilldown.
    - Multiple competing matches, or no usable structured hints (indicator_description
      only) -> escalate to the LLM with only the relevant slice of the Reduced PCAP.

  Mechanism: algorithmic-first (index lookup), LLM escalation reserved for
  ambiguous / non-structured cases. Keeps grounding cost close to O(P + N) rather
  than O(N*P), and avoids re-feeding the full Reduced PCAP to the LLM per claim.
"""

from __future__ import annotations

import json
from typing import Any, Optional

from .fingerprint_utils import IPBehaviorProfile, build_fingerprint_key
from .llm_client import LLMClient
from .models import Actor, Claim, ExpectedIndicators, Grounding, GroundingStatus

# --- Role structural signatures -------------------------------------------------
# Maps a role name to a scoring function over an IPBehaviorProfile. Higher score
# = better fit. This is intentionally small/heuristic and easy to extend; roles
# not listed fall back to a generic "most active endpoint" heuristic.
RoleScorer = "callable[[str, IPBehaviorProfile], float]"

WELL_KNOWN_PORT_CEILING = 1024


def _score_attacker(ip: str, profile: IPBehaviorProfile) -> float:
    return float(profile.destination_cardinality(ip))  # scanning: one src, many dst


def _score_victim(ip: str, profile: IPBehaviorProfile) -> float:
    return float(profile.source_cardinality(ip))  # many sources converge on one dst


def _score_server(ip: str, profile: IPBehaviorProfile) -> float:
    ports = profile.ports_touched_by_ip.get(ip, set())
    return float(sum(1 for p in ports if p < WELL_KNOWN_PORT_CEILING))


def _score_client(ip: str, profile: IPBehaviorProfile) -> float:
    ports = profile.ports_touched_by_ip.get(ip, set())
    return float(sum(1 for p in ports if p >= WELL_KNOWN_PORT_CEILING))


def _score_generic(ip: str, profile: IPBehaviorProfile) -> float:
    return float(profile.packet_count_by_ip.get(ip, 0))


ROLE_SIGNATURES: dict[str, Any] = {
    "attacker": _score_attacker,
    "scanner": _score_attacker,
    "victim": _score_victim,
    "target": _score_victim,
    "server": _score_server,
    "client": _score_client,
}

# --- Confidence scoring -----------------------------------------------------------
# Weighted-sum scorer, structurally the same "Scoring Mechanism" the spec defines
# for the Validator, reused here to produce the Grounder's own confidence value.
_SCORE_WEIGHTS = {
    "protocol_match": 0.20,
    "port_match": 0.15,
    "flags_match": 0.15,
    "direction_match": 0.20,
    "cardinality_match": 0.15,
    "evidence_type": 0.15,
}


def _weighted_confidence(
    protocol_match: float,
    port_match: float,
    flags_match: float,
    direction_match: float,
    cardinality_match: float,
    evidence_type: float,
) -> float:
    return (
        _SCORE_WEIGHTS["protocol_match"] * protocol_match
        + _SCORE_WEIGHTS["port_match"] * port_match
        + _SCORE_WEIGHTS["flags_match"] * flags_match
        + _SCORE_WEIGHTS["direction_match"] * direction_match
        + _SCORE_WEIGHTS["cardinality_match"] * cardinality_match
        + _SCORE_WEIGHTS["evidence_type"] * evidence_type
    )


# --- LLM escalation prompts --------------------------------------------------------

ACTOR_ESCALATION_SYSTEM = """\
You are the Evidence Matcher stage of PANGEA. Actor resolution found multiple
competing candidate IPs for a role and needs a judgment call. You are given ONLY
the role, its description from the text, and the competing candidates with their
behavioral stats - not the full packet capture. Pick the best candidate, or none.

Return ONLY JSON: {"resolved_endpoint": "<ip or null>", "confidence": 0.0-1.0, "basis": "..."}
"""

CLAIM_ESCALATION_SYSTEM = """\
You are the Evidence Matcher stage of PANGEA. A claim could not be resolved
algorithmically (either its structured indicators matched multiple competing
fingerprint buckets, or it has no usable structured indicators and relies on a
free-text indicator_description). You are given the claim and a small, relevant
slice of the Reduced PCAP (not the full capture) to make a judgment call.

Return ONLY JSON:
{
  "status": "grounded" | "unsupported" | "uncertain_needs_drilldown",
  "confidence": 0.0-1.0,
  "linked_packets": [<packet_id>, ...],
  "linked_aggregate_refs": [<fingerprint_key>, ...],
  "basis": "..."
}
"""


class EvidenceMatcher:
    def __init__(
        self,
        reduced_pcap: list[dict[str, Any]],
        fingerprint_index: dict[str, dict[str, Any]],
        llm_client: LLMClient,
        max_llm_slice: int = 40,
    ):
        self.reduced_pcap = reduced_pcap
        self.fingerprint_index = fingerprint_index
        self.llm_client = llm_client
        self.max_llm_slice = max_llm_slice
        self.profile = IPBehaviorProfile(reduced_pcap, fingerprint_index)

    # ------------------------------------------------------------------ actors --

    def resolve_actors(self, actors: list[Actor]) -> list[Actor]:
        for actor in actors:
            self._resolve_actor(actor)
        return actors

    def _resolve_actor(self, actor: Actor) -> None:
        scorer = ROLE_SIGNATURES.get(actor.role.lower(), _score_generic)
        candidates = sorted(
            ((ip, scorer(ip, self.profile)) for ip in self.profile.all_ips()),
            key=lambda pair: pair[1],
            reverse=True,
        )
        candidates = [c for c in candidates if c[1] > 0]

        if not candidates:
            # No match -> unresolved. Dependent claims get flagged later without a
            # wasted lookup (handled in ground_claim).
            return

        top_ip, top_score = candidates[0]
        runner_up_score = candidates[1][1] if len(candidates) > 1 else -1

        if top_score > runner_up_score:
            # Single unambiguous match -> resolved automatically.
            actor.resolved_endpoints = [top_ip]
            actor.resolution_confidence = min(1.0, top_score / (top_score + 1))
            actor.resolution_basis = (
                f"structural signature for role '{actor.role}' scored {top_ip} highest "
                f"({top_score:g}) among {len(candidates)} candidate(s) with nonzero signal"
            )
            return

        # Multiple competing matches (tie at the top) -> escalate to LLM, providing
        # only the specific tied candidates, not the full Reduced PCAP.
        tied = [ip for ip, score in candidates if score == top_score]
        response = self.llm_client.complete_json(
            ACTOR_ESCALATION_SYSTEM,
            json.dumps(
                {
                    "role": actor.role,
                    "description_ref": actor.description_ref,
                    "candidates": [
                        {
                            "ip": ip,
                            "destination_cardinality": self.profile.destination_cardinality(ip),
                            "source_cardinality": self.profile.source_cardinality(ip),
                            "packet_count": self.profile.packet_count_by_ip.get(ip, 0),
                        }
                        for ip in tied
                    ],
                }
            ),
        )
        endpoint = response.get("resolved_endpoint")
        if endpoint:
            actor.resolved_endpoints = [endpoint]
            actor.resolution_confidence = float(response.get("confidence", 0.5))
            actor.resolution_basis = response.get("basis", "LLM-resolved among competing candidates")
        # else: leave unresolved.

    # ------------------------------------------------------------------ claims --

    def ground_claims(self, claims: list[Claim], actors: list[Actor]) -> list[Claim]:
        actor_by_id = {a.actor_id: a for a in actors}
        for claim in claims:
            claim.grounding = self._ground_claim(claim, actor_by_id)
        return claims

    def _ground_claim(self, claim: Claim, actor_by_id: dict[str, Actor]) -> Grounding:
        # Rule: claim depends on an unresolved actor -> immediate uncertain flag,
        # no lookup wasted.
        referenced_actors = [actor_by_id[ref] for ref in claim.actor_refs if ref in actor_by_id]
        if any(not a.is_resolved for a in referenced_actors):
            return Grounding(
                status=GroundingStatus.UNCERTAIN_NEEDS_DRILLDOWN,
                confidence=0.2,
                linked_packets=[],
                linked_aggregate_refs=[],
            )

        ei = claim.expected_indicators
        key = build_fingerprint_key(ei.protocol, ei.port, ei.flags)

        if key is None:
            # No usable structured hints -> escalate with a relevant slice only.
            return self._escalate_claim(claim, referenced_actors)

        matches = self._lookup_candidates(key)

        if len(matches) == 0:
            return Grounding(status=GroundingStatus.UNSUPPORTED, confidence=0.9)

        if len(matches) > 1:
            # Multiple competing fingerprint buckets -> escalate, providing only
            # those candidate buckets (not the whole Reduced PCAP).
            return self._escalate_claim(claim, referenced_actors, candidate_keys=matches)

        # Single clean structural match.
        fp_key = matches[0]
        entry = self.fingerprint_index[fp_key]
        direction_score = self._direction_match_score(entry, referenced_actors, ei)
        cardinality_score = self._cardinality_match_score(entry, ei)

        if entry.get("raw_packet_ids"):
            confidence = _weighted_confidence(
                protocol_match=1.0,
                port_match=1.0 if ei.port is not None else 0.5,
                flags_match=1.0 if ei.flags else 0.5,
                direction_match=direction_score,
                cardinality_match=cardinality_score,
                evidence_type=1.0,  # raw packet evidence
            )
            return Grounding(
                status=GroundingStatus.GROUNDED,
                confidence=confidence,
                linked_packets=entry["raw_packet_ids"],
                linked_aggregate_refs=[],
            )

        # Match exists only as folded aggregate/compressed stats -> can't point to
        # raw packet detail, so this needs deeper investigation rather than a
        # confident grounded/unsupported call.
        confidence = _weighted_confidence(
            protocol_match=1.0,
            port_match=1.0 if ei.port is not None else 0.5,
            flags_match=1.0 if ei.flags else 0.5,
            direction_match=direction_score,
            cardinality_match=cardinality_score,
            evidence_type=0.5,  # aggregate-only evidence
        )
        return Grounding(
            status=GroundingStatus.UNCERTAIN_NEEDS_DRILLDOWN,
            confidence=confidence,
            linked_packets=[],
            linked_aggregate_refs=[fp_key],
        )

    def _lookup_candidates(self, key: str) -> list[str]:
        """Exact key match first; if the claim under-specified flags (key ends in
        the wildcard bucket built by build_fingerprint_key), treat same-protocol
        buckets with concrete flags as competing candidates rather than silently
        picking one.
        """
        if key in self.fingerprint_index:
            return [key]
        protocol_prefix = key.split("|", 1)[0]
        return [k for k in self.fingerprint_index if k.split("|", 1)[0] == protocol_prefix]

    def _direction_match_score(
        self, entry: dict[str, Any], referenced_actors: list[Actor], ei: ExpectedIndicators
    ) -> float:
        if not ei.direction or not referenced_actors:
            return 0.5  # neutral: nothing to check
        endpoints = {ep for a in referenced_actors for ep in a.resolved_endpoints}
        agg = entry.get("aggregate", {})
        seen_ips = set(agg.get("unique_src", [])) | set(agg.get("unique_dst", []))
        for pid in entry.get("raw_packet_ids", []):
            pkt = self._packet_by_id(pid)
            if pkt:
                seen_ips.update({pkt.get("src_ip"), pkt.get("dst_ip")})
        return 1.0 if endpoints & seen_ips else 0.0

    def _cardinality_match_score(self, entry: dict[str, Any], ei: ExpectedIndicators) -> float:
        if not ei.cardinality_pattern:
            return 0.5
        agg = entry.get("aggregate", {})
        n_src, n_dst = len(agg.get("unique_src", [])), len(agg.get("unique_dst", []))
        pattern = ei.cardinality_pattern.lower()
        if pattern == "one-to-many":
            return 1.0 if n_src <= 1 < n_dst else 0.0
        if pattern == "many-to-one":
            return 1.0 if n_dst <= 1 < n_src else 0.0
        if pattern == "one-to-one":
            return 1.0 if n_src <= 1 and n_dst <= 1 else 0.0
        return 0.5

    def _packet_by_id(self, packet_id: Any) -> Optional[dict[str, Any]]:
        for pkt in self.reduced_pcap:
            if pkt.get("packet_id") == packet_id:
                return pkt
        return None

    def _escalate_claim(
        self,
        claim: Claim,
        referenced_actors: list[Actor],
        candidate_keys: Optional[list[str]] = None,
    ) -> Grounding:
        endpoints = {ep for a in referenced_actors for ep in a.resolved_endpoints}
        if candidate_keys:
            relevant_slice = [
                pkt
                for k in candidate_keys
                for pid in self.fingerprint_index[k].get("raw_packet_ids", [])
                if (pkt := self._packet_by_id(pid)) is not None
            ][: self.max_llm_slice]
        elif endpoints:
            relevant_slice = [
                pkt
                for pkt in self.reduced_pcap
                if pkt.get("src_ip") in endpoints or pkt.get("dst_ip") in endpoints
            ][: self.max_llm_slice]
        else:
            relevant_slice = self.reduced_pcap[: self.max_llm_slice]

        response = self.llm_client.complete_json(
            CLAIM_ESCALATION_SYSTEM,
            json.dumps(
                {
                    "claim": claim.to_dict(),
                    "candidate_fingerprint_keys": candidate_keys or [],
                    "relevant_pcap_slice": relevant_slice,
                }
            ),
        )
        if not response:
            return Grounding(status=GroundingStatus.UNCERTAIN_NEEDS_DRILLDOWN, confidence=0.3)

        return Grounding(
            status=GroundingStatus(response.get("status", "uncertain_needs_drilldown")),
            confidence=float(response.get("confidence", 0.5)),
            linked_packets=response.get("linked_packets", []),
            linked_aggregate_refs=response.get("linked_aggregate_refs", []),
        )
