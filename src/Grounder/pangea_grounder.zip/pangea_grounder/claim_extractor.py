"""
Claim Extractor (Grounder sub-component #1).

Per PANGEA_SPEC:
  Responsibility: convert free text into a structured list of atomic claims.
  Input: Traffic Description ONLY. Never receives the Reduced PCAP, so its output
         cannot be biased by what evidence happens to exist in the capture.
  What it does:
    - Splits the description into a flat list of atomic claims.
    - For each claim, defines any technical term used within the claim's own text
      (a prompting instruction, not a separate processing step).
    - Identifies actors referenced in the description (roles such as
      attacker/victim/client/server) - role identification only, not IP resolution.
    - Derives expected_indicators for each claim in two layers:
        * Structured hints (protocol, port, flags, direction, volume pattern,
          cardinality pattern) - used for algorithmic matching.
        * Free-text fallback (indicator_description) - used when a claim doesn't
          reduce cleanly to structured fields.
  Mechanism: necessarily LLM-based - no viable algorithmic substitute.
"""

from __future__ import annotations

from .llm_client import LLMClient
from .models import Actor, Claim, ExpectedIndicators

SYSTEM_PROMPT = """\
You are the Claim Extractor stage of PANGEA, a network-traffic grounding pipeline.

You receive ONLY a free-text Network Traffic Description (an attack narrative, a
protocol behavior description, or an ordinary traffic summary). You do NOT have
access to any packet capture - work purely from the text.

Your job:
1. Split the description into a flat list of atomic, checkable claims. Each claim
   should be a single verifiable statement (do not bundle multiple facts into one
   claim; do not split a single fact into fragments).
2. Within each claim's own text, spell out any technical term used (e.g. instead of
   "the host performed a SYN scan", say "the host sent TCP SYN packets to many ports
   without completing the handshake"), so claims are self-contained.
3. Identify actors referenced in the description (e.g. attacker, victim, client,
   server, scanner, target). This is ROLE IDENTIFICATION ONLY - do not attempt to
   resolve roles to IP addresses; you have no packet evidence to do so.
4. For each claim, derive expected_indicators in two layers:
   a. Structured hints, ONLY when the text clearly implies them:
      - protocol: one of TCP, UDP, ICMP, ARP, DNS, HTTP (or another named protocol)
      - port: a port number, if named or inferable from a named service
      - flags: a list of relevant protocol flags (e.g. ["SYN"], ["SYN","ACK"])
      - direction: expressed using actor_ids, e.g. "attacker->victim"
      - volume_pattern: a short label such as "high", "burst", "steady", "low"
      - cardinality_pattern: a short label such as "one-to-many", "many-to-one",
        "one-to-one"
      Omit any structured field you are not confident about - do not guess.
   b. indicator_description: a free-text fallback description of what evidence
      would support this claim. ALWAYS include this, even when structured fields
      are also present, as a semantic backstop.

Return ONLY a JSON object (no prose, no markdown fences) with this exact shape:
{
  "actors": [
    {"actor_id": "<short_snake_case_id>", "role": "<role>", "description_ref": "<quoted or paraphrased reference from the text>"}
  ],
  "claims": [
    {
      "claim_id": "c1",
      "text": "<self-contained atomic claim>",
      "actor_refs": ["<actor_id>", ...],
      "expected_indicators": {
        "protocol": "...",            // omit if unknown
        "port": 0,                     // omit if unknown
        "flags": ["..."],              // omit if unknown
        "direction": "...",            // omit if unknown
        "volume_pattern": "...",       // omit if unknown
        "cardinality_pattern": "...",  // omit if unknown
        "indicator_description": "..."  // always include
      }
    }
  ]
}
"""

USER_PROMPT_TEMPLATE = """\
Network Traffic Description:
\"\"\"
{description}
\"\"\"

Extract the actors and atomic claims as instructed. Return JSON only.
"""


class ClaimExtractor:
    """Wraps the LLM call and turns its JSON response into typed objects."""

    def __init__(self, llm_client: LLMClient):
        self.llm_client = llm_client

    def extract(self, traffic_description: str) -> tuple[list[Actor], list[Claim]]:
        user_prompt = USER_PROMPT_TEMPLATE.format(description=traffic_description.strip())
        raw = self.llm_client.complete_json(SYSTEM_PROMPT, user_prompt)
        return self._parse(raw)

    @staticmethod
    def _parse(raw: dict) -> tuple[list[Actor], list[Claim]]:
        actors = [
            Actor(
                actor_id=a["actor_id"],
                role=a.get("role", ""),
                description_ref=a.get("description_ref", ""),
            )
            for a in raw.get("actors", [])
        ]

        claims: list[Claim] = []
        for c in raw.get("claims", []):
            ei_raw = c.get("expected_indicators", {}) or {}
            expected_indicators = ExpectedIndicators(
                protocol=ei_raw.get("protocol"),
                port=ei_raw.get("port"),
                flags=ei_raw.get("flags"),
                direction=ei_raw.get("direction"),
                volume_pattern=ei_raw.get("volume_pattern"),
                cardinality_pattern=ei_raw.get("cardinality_pattern"),
                indicator_description=ei_raw.get("indicator_description"),
            )
            claims.append(
                Claim(
                    claim_id=c["claim_id"],
                    text=c["text"],
                    expected_indicators=expected_indicators,
                    actor_refs=c.get("actor_refs", []),
                )
            )
        return actors, claims
