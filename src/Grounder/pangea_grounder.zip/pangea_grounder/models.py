"""
Data models for the Grounder stage.

These mirror the "Matching JSON" schema described in PANGEA_SPEC ("LLM Grounder" ->
Outputs), so that `MatchingResult.to_dict()` serializes to exactly the shape shown
in the spec:

    {
      "actors": [ {...} ],
      "claims": [ {...} ]
    }
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


class GroundingStatus(str, Enum):
    GROUNDED = "grounded"
    UNSUPPORTED = "unsupported"
    UNCERTAIN_NEEDS_DRILLDOWN = "uncertain_needs_drilldown"


@dataclass
class Actor:
    """An actor (role) referenced in the description, e.g. attacker/victim/client/server.

    Produced in two stages:
      - Claim Extractor sets actor_id / role / description_ref (role identification only).
      - Evidence Matcher's Actor Resolution sub-step fills in resolved_endpoints /
        resolution_confidence / resolution_basis (or leaves them empty if unresolved).
    """

    actor_id: str
    role: str
    description_ref: str
    resolved_endpoints: list[str] = field(default_factory=list)
    resolution_confidence: float = 0.0
    resolution_basis: str = ""

    @property
    def is_resolved(self) -> bool:
        return len(self.resolved_endpoints) > 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ExpectedIndicators:
    """Expected evidence signature for a claim, in two layers (per spec, Claim Extractor):

      - Structured hints: protocol, port, flags, direction, volume_pattern,
        cardinality_pattern -- used for algorithmic matching.
      - Free-text fallback: indicator_description -- used when a claim doesn't
        reduce cleanly to structured fields.
    """

    protocol: Optional[str] = None            # "TCP" | "UDP" | "ICMP" | "ARP" | "DNS" | "HTTP" | ...
    port: Optional[int] = None
    flags: Optional[list[str]] = None          # e.g. ["SYN"], ["SYN", "ACK"]
    direction: Optional[str] = None            # e.g. "attacker->victim"
    volume_pattern: Optional[str] = None       # e.g. "high", "burst", "steady"
    cardinality_pattern: Optional[str] = None  # e.g. "one-to-many", "many-to-one"
    indicator_description: Optional[str] = None  # free-text fallback

    @property
    def has_structured_hints(self) -> bool:
        """True if there is enough structured signal to attempt algorithmic matching."""
        return any(
            v is not None
            for v in (self.protocol, self.port, self.flags, self.direction,
                       self.volume_pattern, self.cardinality_pattern)
        )

    def to_dict(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class Grounding:
    status: GroundingStatus = GroundingStatus.UNSUPPORTED
    confidence: float = 0.0
    linked_packets: list[Any] = field(default_factory=list)
    linked_aggregate_refs: list[Any] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "confidence": round(self.confidence, 3),
            "linked_packets": self.linked_packets,
            "linked_aggregate_refs": self.linked_aggregate_refs,
        }


@dataclass
class Claim:
    claim_id: str
    text: str
    expected_indicators: ExpectedIndicators
    actor_refs: list[str] = field(default_factory=list)
    grounding: Grounding = field(default_factory=Grounding)

    def to_dict(self) -> dict[str, Any]:
        return {
            "claim_id": self.claim_id,
            "text": self.text,
            "expected_indicators": self.expected_indicators.to_dict(),
            "actor_refs": self.actor_refs,
            "grounding": self.grounding.to_dict(),
        }


@dataclass
class MatchingResult:
    """The final, unified Grounder output described in the spec."""

    actors: list[Actor] = field(default_factory=list)
    claims: list[Claim] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "actors": [a.to_dict() for a in self.actors],
            "claims": [c.to_dict() for c in self.claims],
        }

    def actor_by_id(self, actor_id: str) -> Optional[Actor]:
        return next((a for a in self.actors if a.actor_id == actor_id), None)
