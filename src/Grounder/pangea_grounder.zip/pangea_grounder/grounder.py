"""
Grounder (top-level stage).

Per PANGEA_SPEC ("LLM Grounder"):
  Purpose: the stage where the traffic description and the packet-level evidence
  (Reduced PCAP) are brought together for the first time. Decomposes a free-text
  description into atomic, checkable claims, and determines - for each claim -
  whether it is supported by the traffic evidence, unsupported, or uncertain
  enough to require deeper investigation.

  Inputs:
    - Network Traffic Description (free text)
    - Reduced PCAP (from Preprocessor)
    - Fingerprint_index (from Preprocessor, reused rather than rebuilt)

  Outputs:
    - Matching JSON: actors[] (role -> IP mapping) and claims[] (claim -> grounding)

Internally this is just wiring: Claim Extractor never sees the PCAP; Evidence
Matcher never re-derives claims. That separation is load-bearing (spec R5-style
separation of forces / avoids the Claim Extractor being biased by the evidence).
"""

from __future__ import annotations

from typing import Any

from .claim_extractor import ClaimExtractor
from .evidence_matcher import EvidenceMatcher
from .llm_client import LLMClient
from .models import MatchingResult


class Grounder:
    def __init__(self, llm_client: LLMClient):
        self.claim_extractor = ClaimExtractor(llm_client)
        self._llm_client = llm_client

    def run(
        self,
        traffic_description: str,
        reduced_pcap: list[dict[str, Any]],
        fingerprint_index: dict[str, dict[str, Any]],
    ) -> MatchingResult:
        # 1. Claim Extractor: text -> claims + actors. No PCAP access (by design).
        actors, claims = self.claim_extractor.extract(traffic_description)

        # 2. Evidence Matcher: resolve actors to IPs, then ground each claim.
        matcher = EvidenceMatcher(reduced_pcap, fingerprint_index, self._llm_client)
        matcher.resolve_actors(actors)
        matcher.ground_claims(claims, actors)

        return MatchingResult(actors=actors, claims=claims)
